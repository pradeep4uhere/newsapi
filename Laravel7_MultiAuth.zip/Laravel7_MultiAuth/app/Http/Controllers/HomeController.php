<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth:user');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $key = "6031aab6de974cd7b26e859a2a49fc98";    
        $url= "https://newsapi.org/v2/top-headlines?country=us&categeory=sport&apiKey=".$key;
        $content = file_get_contents($url);
        $newsList = json_decode($content,true); 

        //Get Indua News
        $url1= "https://newsapi.org/v2/top-headlines?country=in&categeory=all&apiKey=".$key;
        $content1 = file_get_contents($url1);
        $newsListIndia = json_decode($content1,true);
        
        //Get Indua News
        $url2= "http://newsapi.org/v2/everything?q=corona&apiKey=".$key;
        $content2 = file_get_contents($url2);
        $newsCorona = json_decode($content2,true);


          //Get Indua News
        $url3= "http://newsapi.org/v2/everything?q=sports&apiKey=".$key;
        $content3 = file_get_contents($url3);
        $newsSports = json_decode($content3,true);

        //   echo "<pre>";
        // print_r(json_decode($content,true));
        // die;  
            
        return view('welcome',array('newsList'=>$newsList,
            'newsListIndia'=>$newsListIndia,
            'newsCorona'=>$newsCorona,
            'newsSports'=>$newsSports
        ));
    }
}
