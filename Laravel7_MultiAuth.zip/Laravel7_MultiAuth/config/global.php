<?php

$public_path        = public_path();           // /var/www/html/marketadmin/public
$files_path         = $public_path.'/files';
$base_path          = base_path();               // /var/www/html/marketadmin

$public_url         = env('APP_URL');    // http://marketadmin.localhost/


return [

    /*
    * Theme files Path
    */
    'THEME_PATH'     =>  $public_url.'/public/',

    
];

?>

